#ifndef __ArrayGraph_H
#define __ArrayGraph_H
#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <string.h>

#define UNVISITED 0
#define VISITED 1
#define INFINITY INT_MAX
#define ERROR -1
#define OK 1
#define OVERFLOW -1
#define SELECTED 1
#define UNSELECTED O


typedef int Status;

typedef struct Arc {
	int info;//Ȩֵ
	float distant;
}Arc;

typedef struct ArrayDNGraph {
	char* vexs[10];				//��������
	Arc** arcs;					//��ϵ����

	int n, e;					//�������ͱ���
	int* tag;					//��־���飬�����ڱ�־�Ƿ񱻷���
	
}ArrayDNGraph;

typedef struct ArcInfo {
	char v[10], w[10]; //��Ӧ����
	int info;//Ȩֵ
	float distant;
}ArcInfo;

typedef struct c1osedgeInfo {
	int adjInd;
	int lowcost;
}c1osedgeInfo;

int LocateVex(ArrayDNGraph G, char v[]);
int InitGraph(ArrayDNGraph& G, char** vexs, int n);
int GreateGraph(ArrayDNGraph& G, char** vexs, int n, ArcInfo* arcs, int e);
int FirstAdjVex(ArrayDNGraph G, int k);
int NextAdjVex(ArrayDNGraph G, int k, int m);
int AddArc(ArrayDNGraph& G, int k, int m, int info);
int RemoveArc(ArrayDNGraph& G, int k, int m);
int DestroyGraph(ArrayDNGraph& G);
void print_ArrayGraph(ArrayDNGraph G);
Status Prim(ArrayDNGraph G, int i, ArrayDNGraph& T);
#endif
