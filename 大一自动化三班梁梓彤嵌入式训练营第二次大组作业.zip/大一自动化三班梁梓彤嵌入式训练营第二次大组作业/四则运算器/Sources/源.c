#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

// ��ջ�ڵ�ṹ
typedef struct StackNode {
    int data;
    struct StackNode* next;
} StackNode;

// ��ջ�ṹ
typedef struct {
    StackNode* top;
} LinkedStack;

// ��ʼ����ջ
void initStack(LinkedStack* stack) {
    stack->top = NULL;
}

// �ж�ջ�Ƿ�Ϊ��
int isEmpty(LinkedStack* stack) {
    return stack->top == NULL;
}

// ��ջ
void push(LinkedStack* stack, int value) {
    StackNode* newNode = (StackNode*)malloc(sizeof(StackNode));
    newNode->data = value;
    newNode->next = stack->top;
    stack->top = newNode;
}

// ��ջ
int pop(LinkedStack* stack) {
    if (isEmpty(stack)) {
        printf("Stack is empty!\n");
        exit(1);
    }
    StackNode* temp = stack->top;
    int value = temp->data;
    stack->top = temp->next;
    free(temp);
    return value;
}

// ��ȡջ��Ԫ��
int peek(LinkedStack* stack) {
    if (isEmpty(stack)) {
        printf("Stack is empty!\n");
        exit(1);
    }
    return stack->top->data;
}

// �ж��Ƿ�Ϊ�����
int isOperator(char ch) {
    return ch == '+' || ch == '-' || ch == '*' || ch == '/';
}

// ��ȡ��������ȼ�
int precedence(char op) {
    if (op == '+' || op == '-') return 1;
    if (op == '*' || op == '/') return 2;
    return 0;
}

// ִ������
int applyOperation(int a, int b, char op) {
    switch (op) {
    case '+': return a + b;
    case '-': return a - b;
    case '*': return a * b;
    case '/': return a / b;
    default: return 0;
    }
}

// ����ʽ��ֵ
int evaluateExpression(const char* expression) {
    LinkedStack values, operators;
    initStack(&values);
    initStack(&operators);

    for (int i = 0; expression[i]; i++) {
        if (isspace(expression[i])) continue;

        // ��������
        if (isdigit(expression[i])) {
            int num = 0;
            while (expression[i] && isdigit(expression[i])) {
                num = num * 10 + (expression[i] - '0');
                i++;
            }
            i--;
            push(&values, num);
        }

        // ����������
        else if (expression[i] == '(') {
            push(&operators, expression[i]);
        }

        // ����������
        else if (expression[i] == ')') {
            while (peek(&operators) != '(') {
                int b = pop(&values);
                int a = pop(&values);
                char op = pop(&operators);
                push(&values, applyOperation(a, b, op));
            }
            pop(&operators); // ����������
        }

        // ���������
        else if (isOperator(expression[i])) {
            while (!isEmpty(&operators) && precedence(peek(&operators)) >= precedence(expression[i])) {
                int b = pop(&values);
                int a = pop(&values);
                char op = pop(&operators);
                push(&values, applyOperation(a, b, op));
            }
            push(&operators, expression[i]);
        }
    }

    // ����ʣ��������
    while (!isEmpty(&operators)) {
        int b = pop(&values);
        int a = pop(&values);
        char op = pop(&operators);
        push(&values, applyOperation(a, b, op));
    }

    return pop(&values);
}

// ������
int main() {
    char expression[100];
    printf("������һ�������������ʽ��֧�����ţ���\n");
    fgets(expression, sizeof(expression), stdin);
    expression[strcspn(expression, "\n")] = 0; // ȥ�����з�

    int result = evaluateExpression(expression);
    printf("��������%d\n", result);

    return 0;
}
