#include <stdio.h>
#include <stdlib.h>

// ���ڵ�ṹ
typedef struct TreeNode {
    int data;
    struct TreeNode* left;
    struct TreeNode* right;
} TreeNode;

// ջ�ṹ�����ڷǵݹ������
typedef struct StackNode {
    TreeNode* data;
    struct StackNode* next;
} StackNode;

typedef struct Stack {
    StackNode* top;
} Stack;

// ���нṹ�����ڲ��������
typedef struct QueueNode {
    TreeNode* data;
    struct QueueNode* next;
} QueueNode;

typedef struct Queue {
    QueueNode* front, * rear;
} Queue;

TreeNode* createNode(int data) 
{
    TreeNode* newNode = (TreeNode*)malloc(sizeof(TreeNode));
    newNode->data = data;
    newNode->left = newNode->right = NULL;
    return newNode;
}
Stack* createStack() {
    Stack* s = (Stack*)malloc(sizeof(Stack));
    s->top = NULL;
    return s;
}

void push(Stack* s, TreeNode* data) {
    StackNode* newNode = (StackNode*)malloc(sizeof(StackNode));
    newNode->data = data;
    newNode->next = s->top;
    s->top = newNode;
}

TreeNode* pop(Stack* s) {
    if (!s->top) return NULL;
    StackNode* temp = s->top;
    TreeNode* data = temp->data;
    s->top = temp->next;
    free(temp);
    return data;
}

int isStackEmpty(Stack* s) {
    return s->top == NULL;
}

Queue* createQueue() {
    Queue* q = (Queue*)malloc(sizeof(Queue));
    q->front = q->rear = NULL;
    return q;
}

void enqueue(Queue* q, TreeNode* data) {
    QueueNode* newNode = (QueueNode*)malloc(sizeof(QueueNode));
    newNode->data = data;
    newNode->next = NULL;

    if (!q->rear) {
        q->front = q->rear = newNode;
    }
    else {
        q->rear->next = newNode;
        q->rear = newNode;
    }
}

TreeNode* dequeue(Queue* q) {
    if (!q->front) return NULL;

    QueueNode* temp = q->front;
    TreeNode* data = temp->data;
    q->front = q->front->next;

    if (!q->front) q->rear = NULL;
    free(temp);
    return data;
}

int isQueueEmpty(Queue* q) {
    return q->front == NULL;
}

TreeNode* insert(TreeNode* root, int data) {
    if (!root) return createNode(data);

    if (data < root->data) {
        root->left = insert(root->left, data);
    }
    else if (data > root->data) {
        root->right = insert(root->right, data);
    }
    return root;
}

TreeNode* search(TreeNode* root, int data) {
    if (!root || root->data == data) return root;
    return data < root->data ? search(root->left, data) : search(root->right, data);
}

TreeNode* minValueNode(TreeNode* node) {
    while (node && node->left)
        node = node->left;
    return node;
}

TreeNode* deleteNode(TreeNode* root, int data) {
    if (!root) return root;

    if (data < root->data) {
        root->left = deleteNode(root->left, data);
    }
    else if (data > root->data) {
        root->right = deleteNode(root->right, data);
    }
    else {
        if (!root->left) {
            TreeNode* temp = root->right;
            free(root);
            return temp;
        }
        else if (!root->right) {
            TreeNode* temp = root->left;
            free(root);
            return temp;
        }

        TreeNode* temp = minValueNode(root->right);
        root->data = temp->data;
        root->right = deleteNode(root->right, temp->data);
    }
    return root;
}

// �ݹ����
void preOrderRecursive(TreeNode* root) {
    if (root) {
        printf("%d ", root->data);
        preOrderRecursive(root->left);
        preOrderRecursive(root->right);
    }
}

void inOrderRecursive(TreeNode* root) {
    if (root) {
        inOrderRecursive(root->left);
        printf("%d ", root->data);
        inOrderRecursive(root->right);
    }
}

void postOrderRecursive(TreeNode* root) {
    if (root) {
        postOrderRecursive(root->left);
        postOrderRecursive(root->right);
        printf("%d ", root->data);
    }
}

// �ǵݹ����
void preOrderNonRecursive(TreeNode* root) {
    if (!root) return;
    Stack* s = createStack();
    push(s, root);

    while (!isStackEmpty(s)) {
        TreeNode* node = pop(s);
        printf("%d ", node->data);

        if (node->right) push(s, node->right);
        if (node->left) push(s, node->left);
    }
}

void inOrderNonRecursive(TreeNode* root) {
    Stack* s = createStack();
    TreeNode* current = root;

    while (current || !isStackEmpty(s)) {
        while (current) {
            push(s, current);
            current = current->left;
        }
        current = pop(s);
        printf("%d ", current->data);
        current = current->right;
    }
}

void postOrderNonRecursive(TreeNode* root) {
    if (!root) return;
    Stack* s1 = createStack();
    Stack* s2 = createStack();
    push(s1, root);

    while (!isStackEmpty(s1)) {
        TreeNode* node = pop(s1);
        push(s2, node);
        if (node->left) push(s1, node->left);
        if (node->right) push(s1, node->right);
    }

    while (!isStackEmpty(s2)) {
        printf("%d ", pop(s2)->data);
    }
}

// �������
void levelOrder(TreeNode* root) {
    if (!root) return;
    Queue* q = createQueue();
    enqueue(q, root);

    while (!isQueueEmpty(q)) {
        TreeNode* node = dequeue(q);
        printf("%d ", node->data);

        if (node->left) enqueue(q, node->left);
        if (node->right) enqueue(q, node->right);
    }
}

int main() {
    TreeNode* root = NULL;

    // �������
    int values[] = { 50, 30, 70, 20, 40, 60, 80 };
    for (int i = 0; i < sizeof(values) / sizeof(int); i++) {
        root = insert(root, values[i]);
    }

    printf("�ݹ�ǰ�����: ");
    preOrderRecursive(root);
    printf("\n�ǵݹ�ǰ��: ");
    preOrderNonRecursive(root);

    printf("\n\n�ݹ��������: ");
    inOrderRecursive(root);
    printf("\n�ǵݹ�����: ");
    inOrderNonRecursive(root);

    printf("\n\n�ݹ�������: ");
    postOrderRecursive(root);
    printf("\n�ǵݹ����: ");
    postOrderNonRecursive(root);

    printf("\n\n�������: ");
    levelOrder(root);

    // ɾ������
    root = deleteNode(root, 50);
    printf("\n\nɾ��50�������: ");
    inOrderNonRecursive(root);

    return 0;
}
