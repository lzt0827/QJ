#include <stdio.h>
#include <stdlib.h>

#define MAX_HEAP_SIZE 100  

typedef struct {
    int data[MAX_HEAP_SIZE];  
    int size;                 
} MaxHeap;

// ��������ʼ����
MaxHeap* createHeap() {
    MaxHeap* heap = (MaxHeap*)malloc(sizeof(MaxHeap));
    heap->size = 0;
    return heap;
}

// ��ȡ���ڵ�����
int getParentIndex(int index) {
    return (index - 1) / 2;
}

// ��ȡ��������
int getLeftChildIndex(int index) {
    return 2 * index + 1;
}

// ��ȡ�Һ�������
int getRightChildIndex(int index) {
    return 2 * index + 2;
}

void heapifyUp(MaxHeap* heap, int index) {
    while (index > 0 &&
        heap->data[index] > heap->data[getParentIndex(index)]) {
        int temp = heap->data[index];
        heap->data[index] = heap->data[getParentIndex(index)];
        heap->data[getParentIndex(index)] = temp;

        index = getParentIndex(index);
    }
}

void heapifyDown(MaxHeap* heap, int index) {
    int maxIndex = index;

    // �������
    int leftChild = getLeftChildIndex(index);
    if (leftChild < heap->size &&
        heap->data[leftChild] > heap->data[maxIndex]) {
        maxIndex = leftChild;
    }

    // ����Һ���
    int rightChild = getRightChildIndex(index);
    if (rightChild < heap->size &&
        heap->data[rightChild] > heap->data[maxIndex]) {
        maxIndex = rightChild;
    }

    // ������ֵ���ڵ�ǰ�ڵ�
    if (index != maxIndex) {
        // �����ڵ�
        int temp = heap->data[index];
        heap->data[index] = heap->data[maxIndex];
        heap->data[maxIndex] = temp;

        // �ݹ����
        heapifyDown(heap, maxIndex);
    }
}

void insertHeap(MaxHeap* heap, int value) {
    if (heap->size >= MAX_HEAP_SIZE) {
        printf("Heap is full! Insertion failed.\n");
        return;
    }

    // ����Ԫ�ط������λ��
    heap->data[heap->size] = value;
    heap->size++;

    // ���˵�����
    heapifyUp(heap, heap->size - 1);
}

int deleteMax(MaxHeap* heap) {
    if (heap->size == 0) {
        printf("Heap is empty!\n");
        return -1;
    }

    int maxValue = heap->data[0];
    heap->data[0] = heap->data[heap->size - 1];
    heap->size--;

    // ���˵�����
    heapifyDown(heap, 0);

    return maxValue;
}

void printHeap(MaxHeap* heap) {
    printf("Heap elements: ");
    for (int i = 0; i < heap->size; i++) {
        printf("%d ", heap->data[i]);
    }
    printf("\nCurrent size: %d\n", heap->size);
}

int main() {
    MaxHeap* heap = createHeap();

    insertHeap(heap, 30);
    insertHeap(heap, 50);
    insertHeap(heap, 20);
    insertHeap(heap, 80);
    printHeap(heap);  

    printf("\nDeleted max: %d\n", deleteMax(heap));
    printHeap(heap);  

    insertHeap(heap, 45);
    insertHeap(heap, 60);
    printHeap(heap);  

    printf("\nAttempt to delete from empty heap:\n");
    MaxHeap* emptyHeap = createHeap();
    deleteMax(emptyHeap);

    free(heap);
    free(emptyHeap);
    return 0;
}
