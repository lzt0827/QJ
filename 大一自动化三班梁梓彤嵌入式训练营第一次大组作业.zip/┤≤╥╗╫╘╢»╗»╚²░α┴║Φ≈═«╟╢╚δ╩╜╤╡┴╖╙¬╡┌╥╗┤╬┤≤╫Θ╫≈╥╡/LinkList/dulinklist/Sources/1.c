#include "doubly_linked_list.h"

// ��ʼ������
void initList(Node** head) {
    *head = NULL;
}

// �����½ڵ㣨ͷ�巨��
void insertNode(Node** head, int data) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    if (!newNode) {
        printf("�ڴ����ʧ��\n");
        exit(1);
    }
    newNode->data = data;
    newNode->prev = NULL;
    newNode->next = *head;
    if (*head != NULL) {
        (*head)->prev = newNode;
    }
    *head = newNode;
}

// ɾ���ڵ�
void deleteNode(Node** head, int data) {
    if (*head == NULL) {
        printf("����Ϊ�գ��޷�ɾ��\n");
        return;
    }
    Node* current = *head;
    // ����Ҫɾ���Ľڵ�
    while (current != NULL && current->data != data) {
        current = current->next;
    }
    if (current == NULL) {
        printf("δ�ҵ�Ҫɾ���Ľڵ�\n");
        return;
    }
    // ����ǰ���ͺ��ָ��
    if (current->prev != NULL) {
        current->prev->next = current->next;
    }
    else {
        *head = current->next; // ɾ������ͷ�ڵ�
    }
    if (current->next != NULL) {
        current->next->prev = current->prev;
    }
    free(current);
}

// �������
void printList(Node* head) {
    Node* current = head;
    printf("��ǰ����: ");
    while (current != NULL) {
        printf("%d <-> ", current->data);
        current = current->next;
    }
    printf("NULL\n");
}

// ��ת����
void reverseList(Node** head) {
    Node* temp = NULL, * current = *head;
    while (current != NULL) {
        temp = current->prev; // ����ǰ���ͺ��ָ��
        current->prev = current->next;
        current->next = temp;
        current = current->prev; // �ƶ�����һ���ڵ�
    }
    if (temp != NULL) {
        *head = temp->prev; // ����ͷ�ڵ�
    }
}

// �����е�
Node* findMiddle(Node* head) {
    if (head == NULL) return NULL;
    Node* slow = head, * fast = head;
    while (fast != NULL && fast->next != NULL) {
        slow = slow->next;
        fast = fast->next->next;
    }
    return slow;
}

// �ж��Ƿ�ɻ�
int hasCycle(Node* head) {
    if (head == NULL) return 0;
    Node* slow = head, * fast = head;
    while (fast != NULL && fast->next != NULL) {
        slow = slow->next;
        fast = fast->next->next;
        if (slow == fast) return 1;
    }
    return 0;
}

// ��ż����
void swapOddEven(Node** head) {
    if (*head == NULL || (*head)->next == NULL) return;
    Node dummy;
    dummy.next = *head;
    dummy.prev = NULL;
    Node* prev = &dummy, * curr = *head;
    while (curr != NULL && curr->next != NULL) {
        Node* next = curr->next;
        curr->next = next->next;
        if (next->next != NULL) {
            next->next->prev = curr;
        }
        next->prev = prev;
        prev->next = next;
        next->next = curr;
        curr->prev = next;
        prev = curr;
        curr = curr->next;
    }
    *head = dummy.next;
}

// ��ѯ�ڵ�
Node* search(Node* head, int data) {
    Node* current = head;
    while (current != NULL) {
        if (current->data == data) return current;
        current = current->next;
    }
    return NULL;
}

// ����ѭ������
void createCycle(Node* head, int pos) {
    if (head == NULL) return;
    Node* tail = head, * target = NULL;
    int count = 0;
    while (tail->next != NULL) {
        if (count == pos) target = tail;
        tail = tail->next;
        count++;
    }
    if (target != NULL) {
        tail->next = target;
        target->prev = tail;
    }
}

// �ͷ�����
void freeList(Node** head) {
    Node* current = *head;
    Node* next;
    while (current != NULL) {
        next = current->next;
        free(current);
        current = next;
    }
    *head = NULL;
}
