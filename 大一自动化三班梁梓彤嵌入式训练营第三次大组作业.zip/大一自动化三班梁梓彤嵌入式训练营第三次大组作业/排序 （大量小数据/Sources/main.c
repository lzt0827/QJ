#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

// �����㷨����
void InsertSort(int arr[], int n);
void MergeSort(int arr[], int l, int r);
void QuickSort(int arr[], int l, int r);
void CountSort(int arr[], int n);
void RadixCountSort(int arr[], int n);

typedef void (*SortFunc)(int[], int);
void MergeSortWrapper(int arr[], int n);
void QuickSortWrapper(int arr[], int n);

#define DATA_SIZE 100     
#define TEST_TIMES 100000 


void testSort(SortFunc sortFunc, int original[], int n, const char* name);

int main() {
    
    srand(time(NULL));

    int original[DATA_SIZE];
    for (int i = 0; i < DATA_SIZE; i++) {
        original[i] = rand() % 1000; 
    }

    printf("===== С�������������ܲ��� =====\n");
    printf("������: %d\n���Դ���: %d\n", DATA_SIZE, TEST_TIMES);
    printf("================================\n");

   
    testSort(InsertSort, original, DATA_SIZE, "InsertSort");
    testSort(MergeSortWrapper, original, DATA_SIZE, "MergeSort");
    testSort(QuickSortWrapper, original, DATA_SIZE, "QuickSort");
    testSort(CountSort, original, DATA_SIZE, "CountSort");
    testSort(RadixCountSort, original, DATA_SIZE, "RadixCountSort");

    return 0;
}

void testSort(SortFunc sortFunc, int original[], int n, const char* name) {
    int* test_arr = malloc(n * sizeof(int));
    memcpy(test_arr, original, n * sizeof(int));

    clock_t start = clock();
    for (int i = 0; i < TEST_TIMES; i++) {
        memcpy(test_arr, original, n * sizeof(int));
        sortFunc(test_arr, n);
    }
    clock_t end = clock();

    free(test_arr);

    double total_time = ((double)(end - start)) / CLOCKS_PER_SEC;
    printf("%-15s: %.3f s (%.3f us/op)\n",
        name,
        total_time,
        total_time * 1e6 / TEST_TIMES);
}

// ��������
void InsertSort(int arr[], int n) {
    for (int i = 1; i < n; i++) {
        int key = arr[i];
        int j = i - 1;
        while (j >= 0 && arr[j] > key) {
            arr[j + 1] = arr[j];
            j--;
        }
        arr[j + 1] = key;
    }
}

// �鲢����������
void merge(int arr[], int l, int m, int r) {
    int n1 = m - l + 1;
    int n2 = r - m;
    int* L = malloc(n1 * sizeof(int));
    int* R = malloc(n2 * sizeof(int));

    for (int i = 0; i < n1; i++) L[i] = arr[l + i];
    for (int j = 0; j < n2; j++) R[j] = arr[m + 1 + j];

    int i = 0, j = 0, k = l;
    while (i < n1 && j < n2)
        arr[k++] = (L[i] <= R[j]) ? L[i++] : R[j++];
    while (i < n1) arr[k++] = L[i++];
    while (j < n2) arr[k++] = R[j++];

    free(L);
    free(R);
}

// �鲢����
void MergeSort(int arr[], int l, int r) {
    if (l < r) {
        int m = l + (r - l) / 2;
        MergeSort(arr, l, m);
        MergeSort(arr, m + 1, r);
        merge(arr, l, m, r);
    }
}
void MergeSortWrapper(int arr[], int n) {
    MergeSort(arr, 0, n - 1);
}

// ���������������
int partition(int arr[], int l, int r) {
    int pivot = arr[l + (r - l) / 2]; 
    int i = l - 1, j = r + 1;
    while (1) {
        do { i++; } while (arr[i] < pivot);
        do { j--; } while (arr[j] > pivot);
        if (i >= j) return j;
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }
}

// ��������
void QuickSort(int arr[], int l, int r) {
    if (l < r) {
        int p = partition(arr, l, r);
        QuickSort(arr, l, p);
        QuickSort(arr, p + 1, r);
    }
}
void QuickSortWrapper(int arr[], int n) {
    QuickSort(arr, 0, n - 1);
}

// ��������
void CountSort(int arr[], int n) {
    if (n == 0) return;

    int max_val = arr[0];
    for (int i = 1; i < n; i++)
        if (arr[i] > max_val) max_val = arr[i];

    int* count = calloc(max_val + 1, sizeof(int));
    for (int i = 0; i < n; i++) count[arr[i]]++;

    int idx = 0;
    for (int i = 0; i <= max_val; i++)
        while (count[i]-- > 0)
            arr[idx++] = i;

    free(count);
}

// ������������
void RadixCountSort(int arr[], int n) {
    if (n == 0) return;

    int max_val = arr[0];
    for (int i = 1; i < n; i++)
        if (arr[i] > max_val) max_val = arr[i];

#define BASE 10
    int* output = malloc(n * sizeof(int));
    int exp = 1;

    while (max_val / exp > 0) {
        int count[BASE] = { 0 };

        for (int i = 0; i < n; i++)
            count[(arr[i] / exp) % BASE]++;

        for (int i = 1; i < BASE; i++)
            count[i] += count[i - 1];

        for (int i = n - 1; i >= 0; i--) {
            int digit = (arr[i] / exp) % BASE;
            output[--count[digit]] = arr[i];
        }

        memcpy(arr, output, n * sizeof(int));
        exp *= 10;
    }
    free(output);
}
